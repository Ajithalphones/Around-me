from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:root@localhost/around-me'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app)
@app.route('/i')
def i():
   return render_template('dex.html')
@app.route('/ad')
def ad():
   return render_template('ad.html')  
@app.route('/log')
def log():
   return render_template('logi.html')   
@app.route('/regi')
def regi():
   return render_template('register.html')
@app.route('/user')
def user():
   return render_template('user.html')
@app.route('/disst')  
def disst():
   return render_template('district.html')
@app.route('/rest') 
def rest():
   return render_template('restaruants.html') 
@app.route('/resort') 
def resort():
   return render_template('resorts.html')   
@app.route('/val') 
def val():
   return render_template('value.html')
@app.route('/place') 
def place():
   return render_template('place.html')                
@app.route('/option')  
def option():
   return render_template('option.html') 
@app.route('/a2')
def a2():
   return render_template('searchs.html')
@app.route('/home')
def home():
   return render_template('home.html')
@app.route('/map')
def map():
   return render_template('maps.html')
@app.route('/traffic')
def traffic():
   return render_template('traffic.html') 
@app.route('/spots')
def spots():
   return render_template('spot.html')
@app.route('/cbe')
def cbe():
   return render_template('cbe.html')     
@app.route('/short')
def short():
   return render_template('short.html')
@app.route('/view_hotel/<name>')
def view_hotel(name):
   return render_template('view.html',value=value.query.filter_by(hotelname='%s'%name))
@app.route('/view_all')
def view_all():
   return render_template('view_all.html',value=value.query.all(),restarunt=restarunt.query.all(),resort=resort.query.all())
@app.route('/view_city')
def view_city():
   return render_template('view_city.html',city=city.query.all())  
@app.route('/vuser')
def view_user():
   return render_template('view_user.html',aroundme=aroundme.query.all())   
    

class aroundme(db.Model):
	id = db.Column('demo_id',db.Integer, primary_key = True)
	name = db.Column(db.String(100))
	username = db.Column(db.String(50))
	password = db.Column(db.String(200)) 
	confirm = db.Column(db.String(10))
	email = db.Column(db.String(100))

	def __init__(self, name,username, password, confirm,email):
		self.name = name
		self.username = username
		self.password = password
		self.confirm = confirm
		self.email = email

	@app.route('/log', methods = ['GET', 'POST'])
	def new1():
		if request.method == 'POST':
			if not request.form['name']  or not request.form['username'] or not request.form['password'] or not request.form ['confirm'] or not request.form['email']:
				flash('Please enter all the fields', 'error')
			else:
				demo = aroundme(request.form['name'], request.form['username'], request.form['password'], request.form['confirm'] , request.form['email'])
				db.session.add(demo)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('log'))
				return render_template('logi.html')
				
@app.route('/logg', methods=['POST','GET'])
def logg():
	if request.method=='GET':
		return render_template('logi.html')
	username = request.form['username']
	password = request.form['password']
	demo=aroundme.query.filter_by(username=username,password=password).first()
	if request.form['password'] == 'admin' and request.form['username'] == 'admin':
		return redirect(url_for('ad'))
	if demo is None:
		return render_template("logi.html")
	else:
		return render_template("user.html")
class value(db.Model):
	id = db.Column('vls_id',db.Integer, primary_key = True)
	hotelname = db.Column(db.String(100))
	arealocated = db.Column(db.String(100))
	address = db.Column(db.String(50))
	phoneno = db.Column(db.String(200)) 
	review = db.Column(db.String(10))
	def __init__(self, hotelname, arealocated, address, phoneno, review):
		self.hotelname = hotelname
		self.arealocated = arealocated
		self.address = address
		self.phoneno = phoneno
		self.review = review
	@app.route('/val', methods = ['GET', 'POST'])
	def new2():
		if request.method == 'POST':
			if not request.form['hotelname'] or not request.form['arealocated'] or not request.form['address'] or not request.form['phoneno'] or not request.form ['review']:
				flash('Please enter all the fields', 'error')
			else:
				vls = value(request.form['hotelname'], request.form['arealocated'], request.form['address'], request.form['phoneno'], request.form['review'])
				db.session.add(vls)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('ad'))
		return render_template('value.html')		

@app.route('/view', methods=['POST','GET'])
def hotel_view():
	if request.method=='GET':
		return render_template('view.html')
	search = request.form['search']
	return redirect(url_for('view_hotel',name=search))

class resort(db.Model):
	id = db.Column('rsrt_id',db.Integer, primary_key = True)
	resortsname = db.Column(db.String(100))
	arealocated = db.Column(db.String(100))
	address = db.Column(db.String(50))
	phoneno = db.Column(db.String(200)) 
	review = db.Column(db.String(10))
	def __init__(self, resortsname, arealocated, address, phoneno, review):
		self.resortsname = resortsname
		self.arealocated = arealocated
		self.address = address
		self.phoneno = phoneno
		self.review = review
	@app.route('/resort', methods = ['GET', 'POST'])
	def new3():
		if request.method == 'POST':
			if not request.form['resortsname'] or not request.form['arealocated'] or not request.form['address'] or not request.form['phoneno'] or not request.form ['review']:
				flash('Please enter all the fields', 'error')
			else:
				rsrt = resort(request.form['resortsname'], request.form['arealocated'], request.form['address'], request.form['phoneno'], request.form['review'])
				db.session.add(rsrt)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('ad'))
		return render_template('resort.html')
						
class restarunt(db.Model):
	id = db.Column('rests_id',db.Integer, primary_key = True)
	restaruantname = db.Column(db.String(100))
	arealocated = db.Column(db.String(100))
	address = db.Column(db.String(50))
	phoneno = db.Column(db.String(200)) 
	review = db.Column(db.String(10))
	def __init__(self, restaruantname, arealocated, address, phoneno, review):
		self.restaruantname = restaruantname
		self.arealocated = arealocated
		self.address = address
		self.phoneno = phoneno
		self.review = review
	@app.route('/rest', methods = ['GET', 'POST'])
	def new4():
		if request.method == 'POST':
			if not request.form['restaruantname'] or not request.form['arealocated'] or not request.form['address'] or not request.form['phoneno'] or not request.form ['review']:
				flash('Please enter all the fields', 'error')
			else:
				rests = restarunt(request.form['restaruantname'], request.form['arealocated'], request.form['address'], request.form['phoneno'], request.form['review'])
				db.session.add(rests)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('ad'))
		return render_template('restarunt.html')
class city(db.Model):
	id = db.Column('town_id',db.Integer, primary_key = True)
	cityname = db.Column(db.String(100))
	
	def __init__(self, cityname):
		self.cityname = cityname
		
	@app.route('/place', methods = ['GET', 'POST'])
	def new5():
		if request.method == 'POST':
			if not request.form['cityname']:
				flash('Please enter all the fields', 'error')
			else:
				town = city(request.form['cityname'])
				db.session.add(town)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('ad'))
		        return render_template('place.html')
		
		
						
if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)
