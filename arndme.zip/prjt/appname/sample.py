from flask import Flask,render_template
app = Flask(__name__)
@app.route('/i')
def i():
   return render_template('i.html')
@app.route('/a2')
def a2():
   return render_template('a2.html')
@app.route('/home')
def home():
   return render_template('home.html')
@app.route('/map')
def map():
   return render_template('map.html')
@app.route('/traffic')
def traffic():
   return render_template('traffic.html') 
@app.route('/short')
def short():
   return render_template('short.html')              

if __name__ == '__main__':
   app.run(debug = True)
